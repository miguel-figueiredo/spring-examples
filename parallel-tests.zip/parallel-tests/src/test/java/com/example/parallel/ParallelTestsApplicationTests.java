package com.example.parallel;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ParallelTestsApplicationTests {

	@Test
	void contextLoads() {
	}

}
